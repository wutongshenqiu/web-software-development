create table if not exists test.tb_building
(
    id              bigint auto_increment
        primary key,
    create_time     timestamp     not null,
    remark          varchar(1000) null,
    update_time     timestamp     not null,
    building_status int           not null,
    description     varchar(1000) null,
    image_url       varchar(255)  null,
    name            varchar(100)  not null
);

create table if not exists test.tb_role
(
    id          bigint auto_increment
        primary key,
    create_time timestamp     not null,
    remark      varchar(1000) null,
    update_time timestamp     not null,
    description varchar(1000) null,
    name        varchar(100)  not null,
    role_status int           not null,
    constraint UK_1ncmoedv5ta7r19y9d4oidn0y
        unique (name)
);

create index IDX1ncmoedv5ta7r19y9d4oidn0y
    on test.tb_role (name);

create table if not exists test.tb_room
(
    id          bigint auto_increment
        primary key,
    create_time timestamp     not null,
    remark      varchar(1000) null,
    update_time timestamp     not null,
    description varchar(1000) null,
    gender      int           not null,
    image_url   varchar(255)  null,
    name        varchar(100)  not null,
    building_id bigint        not null,
    constraint FK4tkvahh487gxtasy87ercho40
        foreign key (building_id) references test.tb_building (id)
);

create table if not exists test.tb_sys_config
(
    id                bigint auto_increment
        primary key,
    create_time       timestamp     not null,
    remark            varchar(1000) null,
    update_time       timestamp     not null,
    key_name          varchar(100)  not null,
    key_value         varchar(1000) not null,
    sys_config_status int           not null
);

create table if not exists test.tb_user
(
    id          bigint auto_increment
        primary key,
    create_time timestamp     not null,
    remark      varchar(1000) null,
    update_time timestamp     not null,
    email       varchar(100)  not null,
    gender      int           not null,
    name        varchar(100)  not null,
    telephone   varchar(30)   not null,
    user_status int           not null,
    constraint UK_4vih17mube9j7cqyjlfbcrk4m
        unique (email),
    constraint UK_ng6mku3welo8fs5svoft51430
        unique (telephone)
);

create table if not exists test.tb_auth
(
    id              bigint auto_increment
        primary key,
    create_time     timestamp     not null,
    remark          varchar(1000) null,
    update_time     timestamp     not null,
    auth_status     int           not null,
    auth_type       int           not null,
    last_login_time timestamp     null,
    password        varchar(255)  not null,
    username        varchar(50)   not null,
    user_id         bigint        not null,
    constraint FKpuk9pj7sn1pesf6cjjyrvvbyq
        foreign key (user_id) references test.tb_user (id)
);

create table if not exists test.tb_bed
(
    id          bigint auto_increment
        primary key,
    create_time timestamp     not null,
    remark      varchar(1000) null,
    update_time timestamp     not null,
    bed_status  int           not null,
    name        varchar(100)  not null,
    room_id     bigint        not null,
    user_id     bigint        null,
    constraint FK6o5u5h26ranj7rvbdh4ky5sdb
        foreign key (room_id) references test.tb_room (id),
    constraint FKog7ccybonpkcy3jgrv5nt3fgb
        foreign key (user_id) references test.tb_user (id)
);

create table if not exists test.tb_group
(
    id           bigint auto_increment
        primary key,
    create_time  timestamp     not null,
    remark       varchar(1000) null,
    update_time  timestamp     not null,
    description  varchar(1000) null,
    group_status int           not null,
    invite_code  varchar(100)  not null,
    name         varchar(100)  not null,
    creator_id   bigint        not null,
    constraint UK_qnjkl9tqgw7ssl836mx5l7uxa
        unique (invite_code),
    constraint FKmc6x9vr2eps1qmwn1md2lei2y
        foreign key (creator_id) references test.tb_user (id)
);

create table if not exists test.tb_form
(
    id             bigint auto_increment
        primary key,
    create_time    timestamp     not null,
    remark         varchar(1000) null,
    update_time    timestamp     not null,
    finish_time    timestamp     null,
    form_status    int           not null,
    result_content varchar(1000) null,
    building_id    bigint        not null,
    group_id       bigint        not null,
    room_id        bigint        null,
    submitter_id   bigint        not null,
    constraint FK96jq46cfyyhx0j432rcsbfnnw
        foreign key (group_id) references test.tb_group (id),
    constraint FKdqv1kxk4abhotn1ofoh44ks9b
        foreign key (submitter_id) references test.tb_user (id),
    constraint FKi68jwgb7xxaa8ebuksf8afko2
        foreign key (building_id) references test.tb_building (id),
    constraint FKl5uo456v38w2g4rvrvest39cf
        foreign key (room_id) references test.tb_room (id)
);

create index IDXa45avhxrwey3oq9mibn0xqfj0
    on test.tb_group (invite_code);

create table if not exists test.tb_group_member
(
    id                  bigint auto_increment
        primary key,
    create_time         timestamp     not null,
    remark              varchar(1000) null,
    update_time         timestamp     not null,
    group_member_status int           not null,
    join_time           timestamp     not null,
    leave_time          timestamp     null,
    group_id            bigint        not null,
    member_id           bigint        not null,
    constraint FK63jty2uu0iik0t8t5u49ay3dg
        foreign key (group_id) references test.tb_group (id),
    constraint FKf3n0s35c1iqj1do3camtqo2av
        foreign key (member_id) references test.tb_user (id)
);

create table if not exists test.tb_log
(
    id          bigint auto_increment
        primary key,
    create_time timestamp     not null,
    remark      varchar(1000) null,
    update_time timestamp     not null,
    content     varchar(1000) null,
    ip          varchar(50)   not null,
    log_status  int           not null,
    operation   varchar(500)  not null,
    user_id     bigint        not null,
    constraint FKha2pl1pcudlhfjtpx652iw4s0
        foreign key (user_id) references test.tb_user (id)
);

create table if not exists test.tb_student_info
(
    id          bigint auto_increment
        primary key,
    create_time timestamp     not null,
    remark      varchar(1000) null,
    update_time timestamp     not null,
    student_id  varchar(50)   not null,
    user_id     bigint        not null,
    constraint UK_2ow7hqokkcrmph27o0tdwyb6b
        unique (student_id),
    constraint FKhh7wmv5tynbauqcumesid5lb4
        foreign key (user_id) references test.tb_user (id)
);

create index IDXf1c2hp0myupj4iua8ocr5ip20
    on test.tb_student_info (student_id);

create index IDX4vih17mube9j7cqyjlfbcrk4m
    on test.tb_user (email);

create index IDXng6mku3welo8fs5svoft51430
    on test.tb_user (telephone);

create table if not exists test.tb_user_role
(
    user_id bigint not null,
    role_id bigint not null,
    primary key (user_id, role_id),
    constraint FK7vn3h53d0tqdimm8cp45gc0kl
        foreign key (user_id) references test.tb_user (id),
    constraint FKea2ootw6b6bb0xt3ptl28bymv
        foreign key (role_id) references test.tb_role (id)
);
